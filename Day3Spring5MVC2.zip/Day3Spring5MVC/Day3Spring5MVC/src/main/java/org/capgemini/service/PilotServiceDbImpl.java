package org.capgemini.service;

import java.util.List;
import org.capgemini.dao.PilotDao;
import org.capgemini.model.Login;
import org.capgemini.model.Pilot;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("pilotDbService")
public class PilotServiceDbImpl implements PilotService{

	@Autowired
	private PilotDao pilotDbDao;
	
	@Override
	public void save(Pilot pilot) {
		// TODO Auto-generated method stub
		pilotDbDao.save(pilot);		
	}

	@Override
	public List<Pilot> getAll() {
		// TODO Auto-generated method stub
		return pilotDbDao.getAll();
	}

	@Override
	public void delete(int pilotId) {
		// TODO Auto-generated method stub
		pilotDbDao.delete(pilotId);
	}

	@Override
	public Pilot getPilot(int pilotId) {
		// TODO Auto-generated method stub
		return pilotDbDao.getPilot(pilotId);
	}

	@Override
	public void update(Pilot pilot1) {
		// TODO Auto-generated method stub
		pilotDbDao.update(pilot1);
	}

	@Override
	public List<Login> getAllLogins() {
		// TODO Auto-generated method stub
		return pilotDbDao.getAllLogins();
	}

}
