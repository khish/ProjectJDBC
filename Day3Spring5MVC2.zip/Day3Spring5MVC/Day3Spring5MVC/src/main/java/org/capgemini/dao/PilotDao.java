package org.capgemini.dao;

import java.util.List;

import org.capgemini.model.Login;
import org.capgemini.model.Pilot;

public interface PilotDao {

	public void save(Pilot pilot);
	public List<Pilot> getAll();
	public void delete(int pilotId);
	public Pilot getPilot(int pilotId);
	public void update(Pilot pilot1);
	public List<Login> getAllLogins();
	
}
