package org.capgemini.controller;

import java.util.List;

import javax.validation.Valid;

import org.capgemini.model.Login;
import org.capgemini.model.Pilot;
import org.capgemini.service.PilotService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class ControllerClass {

	private Pilot pilot;
	
	@Autowired
	private PilotService pilotService;
	
	@RequestMapping("/Click")
	public ModelAndView doClick() {
		return new ModelAndView("Page2","content","Welcome to Spring 5!");
	}
	
	@RequestMapping("/validateLogin")
	public String validlogin(ModelMap map,
			@RequestParam("username")String username,
			@RequestParam("password")String password) {
		
		List<Login> login = pilotService.getAllLogins();
		for (Login log : login) {
			if((log.getUname().equals(username))&&(log.getUpass().equals(password))) {
				List<Pilot> pilots = pilotService.getAll(); 
				map.put("pilots", pilots);
				map.put("piloted", new Pilot());
				return "pilotForm";
			}
		}
		return "redirect:/";
	}
	
	@RequestMapping("/pilotForm")
	public String getPilotForm(ModelMap map) {
		List<Pilot> pilots = pilotService.getAll(); 
		map.put("pilots", pilots);
		
		if(pilot!=null) {
			map.put("piloted",pilot);
		}
		else {
			map.put("piloted", new Pilot());			
		}
		return "pilotForm";
	}
	
	@PostMapping("/savePilot")
	public String showPilotDetails(
			@Valid @ModelAttribute("piloted") Pilot pilotIn,BindingResult result) {
			if(!result.hasErrors()) {
				pilotService.update(pilotIn);
				System.out.println(pilotIn);
				pilot=null;
			}
			return "redirect:pilotForm";			
	}
	
	@GetMapping("/delete/{pilotId}")
	public String deletePilot(@PathVariable("pilotId")Integer pilotId) {
		pilotService.delete(pilotId);
		return "redirect:/pilotForm";
	}
	
	@GetMapping("/edit/{pilotId}")
	public String updatePilot(@PathVariable("pilotId")Integer pilotId,ModelMap map) {
		pilot = pilotService.getPilot(pilotId);
		return "redirect:/pilotForm";
	}
	
}
