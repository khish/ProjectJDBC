package org.cap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.cap.model.Login;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository("walletDao")
@Transactional
public class WalletDao implements IWalletDao{

	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public List<Login> getAllLogin() {
		List<Login> login = entityManager.createQuery("from Login").getResultList();
		return login;
	}

	@Override
	public void setLastLogin(Login log) {
		entityManager.merge(log);		
	}

	
	
}
