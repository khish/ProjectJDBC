package org.cap.dao;

import java.util.List;
import org.cap.model.Login;


public interface IWalletDao {

	public List<Login> getAllLogin();
	public void setLastLogin(Login log);
	
}
