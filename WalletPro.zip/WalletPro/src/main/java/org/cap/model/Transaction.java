package org.cap.model;

public class Transaction {

}
