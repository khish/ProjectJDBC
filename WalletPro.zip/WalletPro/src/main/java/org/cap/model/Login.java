package org.cap.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Login {

	@Id
	private String uname;
	private String upass;
	private String accStatus;
	private Date lastLog;
	
	public Login() {
		super();
	}
	public Login(String uname, String upass, String accStatus, Date lastLog) {
		super();
		this.uname = uname;
		this.upass = upass;
		this.accStatus = accStatus;
		this.lastLog = lastLog;
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getUpass() {
		return upass;
	}
	public void setUpass(String upass) {
		this.upass = upass;
	}

	public String getAccStatus() {
		return accStatus;
	}

	public void setAccStatus(String accStatus) {
		this.accStatus = accStatus;
	}

	public Date getLastLog() {
		return lastLog;
	}

	public void setLastLog(Date lastLog) {
		this.lastLog = lastLog;
	}
}