package org.cap.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.Id;

@Entity
public class Account {

	@Id
	private String accId;
	private int accNo;
	private String accType;
	private double oBalance;
	private Date oDate;
	private int custId;
	public String getAccId() {
		return accId;
	}
	public void setAccId(String accId) {
		this.accId = accId;
	}
	public int getAccNo() {
		return accNo;
	}
	public void setAccNo(int accNo) {
		this.accNo = accNo;
	}
	public String getAccType() {
		return accType;
	}
	public void setAccType(String accType) {
		this.accType = accType;
	}
	public double getoBalance() {
		return oBalance;
	}
	public void setoBalance(double oBalance) {
		this.oBalance = oBalance;
	}
	public Date getoDate() {
		return oDate;
	}
	public void setoDate(Date oDate) {
		this.oDate = oDate;
	}
	public int getCustId() {
		return custId;
	}
	public void setCustId(int custId) {
		this.custId = custId;
	}
	public Account(String accId, int accNo, String accType, double oBalance, Date oDate, int custId) {
		super();
		this.accId = accId;
		this.accNo = accNo;
		this.accType = accType;
		this.oBalance = oBalance;
		this.oDate = oDate;
		this.custId = custId;
	}
	
	public Account() {
		super();
	}
	@Override
	public String toString() {
		return "Account [accId=" + accId + ", accNo=" + accNo + ", accType=" + accType + ", oBalance=" + oBalance
				+ ", oDate=" + oDate + ", custId=" + custId + "]";
	}	
	
	
}
