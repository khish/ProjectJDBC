package org.cap.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class WalletController {

	@RequestMapping("/validateLogin")
	public String validlogin(ModelMap map,
			@RequestParam("userName")String username,
			@RequestParam("userPwd")String password) {
		
		if((username.equals("khish"))&&(password.equals("khish123"))) {
			return "MainPage";
		}
		return "redirect:/";
	}

}
