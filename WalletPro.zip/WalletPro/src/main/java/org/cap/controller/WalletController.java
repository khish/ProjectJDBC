package org.cap.controller;

import java.util.Date;
import java.util.List;

import org.cap.model.Login;
import org.cap.service.IWalletService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class WalletController {
	
	@Autowired
	private IWalletService walletService;

	@RequestMapping("/validateLogin")
	public String validlogin(ModelMap map,
			@RequestParam("userName")String username,
			@RequestParam("userPwd")String password) {
		
		List<Login> login = walletService.getAllLogin();
		for (Login log : login) {
			if((log.getUname().equals(username))&&(log.getUpass().equals(password))) {
				log.setLastLog(new Date());
				walletService.setLastLogin(log);
				return "MainPage";
			}
		}
		return "redirect:/";
	}
	
	@GetMapping("/createAccount")
	public String createAccPage() {
		return "createAccount";
	}
	
	@GetMapping("/Deposit")
	public String depositPage() {
		return "Deposit";
	}
	@GetMapping("/fundTransfer")
	public String fundTransferPage() {
		return "fundTransfer";
	}
	
	@GetMapping("/Logout")
	public String Logout() {
		return "Logout";
	}
	@GetMapping("/printTransaction")
	public String printTransactionPage() {
		return "printTransaction";
	}
	@GetMapping("/showBalance")
	public String showBalancePage() {
		return "showBalance";
	}
	@GetMapping("/withdraw")
	public String withdrawPage() {
		return "withdraw";
	}
	
}
