package org.cap.service;

import java.util.List;

import org.cap.dao.IWalletDao;
import org.cap.model.Login;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("walletService")
public class WalletService implements IWalletService {

	@Autowired
	private IWalletDao walletDao;
	
	@Override
	public List<Login> getAllLogin() {
		// TODO Auto-generated method stub
		return walletDao.getAllLogin();
	}

	@Override
	public void setLastLogin(Login log) {
		// TODO Auto-generated method stub
		walletDao.setLastLogin(log);
	}

	
}
