package org.cap.service;

import java.util.List;
import org.cap.model.Login;

public interface IWalletService {

	public List<Login> getAllLogin();
	public void setLastLogin(Login log);
	
}
