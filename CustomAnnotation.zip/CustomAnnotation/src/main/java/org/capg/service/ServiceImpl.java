package org.capg.service;

import org.capg.dao.Dao;
import org.capg.model.Login;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("serviceImpl")
public class ServiceImpl implements org.capg.service.Service{

	@Autowired
	private Dao daoImpl;
	
	public void save(Login log) {
		// TODO Auto-generated method stub
		daoImpl.save(log);		
	}

	
	
}
