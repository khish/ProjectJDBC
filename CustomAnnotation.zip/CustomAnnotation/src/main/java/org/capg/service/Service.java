package org.capg.service;

import org.capg.model.Login;

public interface Service {

	public void save(Login log);

}
