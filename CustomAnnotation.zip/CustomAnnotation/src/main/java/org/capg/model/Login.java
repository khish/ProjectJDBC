package org.capg.model;

import javax.persistence.Entity;
import javax.persistence.Id;

import org.capg.annotation.ContainsAt;

@Entity
public class Login {

	@Id
	@ContainsAt(value="@",message="username should contain @")
	private String uname;
	private String upass;
	
	public Login() {
		super();
	}
	public Login(String uname, String upass) {
		super();
		this.uname = uname;
		this.upass = upass;
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getUpass() {
		return upass;
	}
	public void setUpass(String upass) {
		this.upass = upass;
	}
}