package org.capg.annotation;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class Validator implements ConstraintValidator<ContainsAt, String> {

	public void initialize(ContainsAt theword) {
		// TODO Auto-generated method stub
		
	}

	public boolean isValid(String value, ConstraintValidatorContext context) {
		boolean result;
		
		if(value!=null)
			result=value.contains("@");
		else
			result=true;		
		return false;
	}

}
