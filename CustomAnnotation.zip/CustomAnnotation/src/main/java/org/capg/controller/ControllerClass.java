package org.capg.controller;

import org.capg.model.Login;
import org.capg.service.Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class ControllerClass {

	@Autowired
	private Service serviceImpl;
	
	@RequestMapping("/validateLogin")
	public String getPage(@ModelAttribute("log") Login l1 ,BindingResult result) {
		if(!result.hasErrors()) {
			serviceImpl.save(l1);
			return "secondPage";
		}
		return "redirect";
	}
	
}
