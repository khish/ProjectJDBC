package org.capg.dao;

import org.capg.model.Login;

public interface Dao {

	public void save(Login log);
	
}
