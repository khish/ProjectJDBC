package org.capg.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.capg.model.Login;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository("daoImpl")
@Transactional
public class DaoImpl implements Dao{
	
	@PersistenceContext
	private EntityManager entityManager;
	
	public void save(Login log) {
		entityManager.persist(log);
	}
	
}