package org.cap.exception;

public class InvalidOpeningBalance extends Exception {

	public InvalidOpeningBalance() {
		super();
	}
	public InvalidOpeningBalance(String message) {
		super(message);
	}
}
