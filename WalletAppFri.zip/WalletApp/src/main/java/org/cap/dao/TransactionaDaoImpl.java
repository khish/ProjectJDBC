package org.cap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.cap.model.Transaction;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository("transactionDao")
@Transactional
public class TransactionaDaoImpl implements ITransactionDao{

	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public void createAccount(Transaction transaction) {
		
		/*Query query= entityManager.createQuery("select max(transactionId) from Transaction");
		List<Integer> max= query.getResultList();
		transaction.setTransactionId(max.get(0)+1)*/
		
		entityManager.persist(transaction);
	}
	
	@Override
	public List<Transaction> getTransactions(Integer custId) {
		// TODO Auto-generated method stub
		
		Query query= entityManager.createQuery("from Transaction transaction where transaction.customer.customerId=:cust");
		query.setParameter("cust", custId);
			List<Transaction> transaction= query.getResultList();
		for (Transaction trans : transaction) {
			System.out.println(trans);
		}
		
		return transaction;
	}
	
}
