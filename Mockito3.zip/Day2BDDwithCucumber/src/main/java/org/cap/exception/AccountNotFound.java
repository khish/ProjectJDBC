package org.cap.exception;

public class AccountNotFound extends Exception {

	public AccountNotFound() {
		// TODO Auto-generated constructor stub
	super();
	}
	public AccountNotFound(String message) {
		super(message);
	}
	
}
