package org.cap.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import org.cap.model.Pilot;
import org.springframework.stereotype.Repository;

@Repository("pilotDao")
public class PilotDaoImpl implements IPilotDao{

	private static AtomicInteger pilotId=new AtomicInteger(1000);
	
	public static List<Pilot> pilots=dummyDbPilot();
	
	private static List<Pilot> dummyDbPilot(){
		List<Pilot> pilots = new ArrayList<>();
		pilots.add(new Pilot(pilotId.incrementAndGet(),"Tom","Jerry",new Date(1991-1900,3,12),new Date(), true,23000,"khish@kk.com"));
		pilots.add(new Pilot(pilotId.incrementAndGet(),"Jack","Joot",new Date(2011-1900,4,13),new Date(), true,83000,"kh@kk.com"));
		pilots.add(new Pilot(pilotId.incrementAndGet(),"Jessy","Joel",new Date(2001-1900,5,16),new Date(), true,43000,"khsh@kk.com"));
		pilots.add(new Pilot(pilotId.incrementAndGet(),"John","Jerry",new Date(2005-1900,7,11),new Date(), true,73000,"ish@kk.com"));
		pilots.add(new Pilot(pilotId.incrementAndGet(),"Rohit","Sham",new Date(1996-1900,8,19),new Date(), true,55000,"kis@kk.com"));
		return pilots;
	}
	
	@Override
	public List<Pilot> getAllPilots() {
		// TODO Auto-generated method stub
		return pilots;
	}

	@Override
	public Pilot findPilot(int pilotId) {
		for (Pilot pilot : pilots) {
			if(pilot.getPilotId()==pilotId) {
				return pilot;
			}
		}
		return null;
	}

	@Override
	public List<Pilot> deletePilot(int pilotId) {
		Iterator<Pilot> itr = pilots.iterator();
	      while(itr.hasNext()) {
	         Pilot element = itr.next();
	         if(element.getPilotId()==pilotId) {
	        	 itr.remove();
	        	 return pilots;
	         }
	      }
		return null;
	}

	@Override
	public List<Pilot> createPilot(Pilot pilot) {
		pilots.add(pilot);
		return pilots;
	}

	@Override
	public List<Pilot> updatePilot(Pilot pilot) {
		Iterator<Pilot> itr = pilots.iterator();
	      while(itr.hasNext()) {
	         Pilot element = itr.next();
	         if(element.getPilotId()==pilot.getPilotId()) {
	        	 itr.remove();
	        	 pilots.add(pilot);
	        	 return pilots;	        	 
	         }
	      }
		return null;
	}

}
