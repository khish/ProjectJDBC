package com.mywallet.client;

import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.mywallet.bean.Customer;
import com.mywallet.exception.WalletException;
import com.mywallet.service.IWalletService;
import com.mywallet.service.WalletService;

public class App 
{
    IWalletService bs = new WalletService();
	Scanner scan = new Scanner(System.in);
	Logger logger = Logger.getRootLogger();
	
	
	public static void main(String[] args) {
		
		PropertyConfigurator.configure("resources//log4j.properties");
		
		String option = null;
		String option1 = null;
		boolean menu = true;
				
		App a = new App();
		while(true) {
			System.out.println("===============XYZ Banking Services=============");
			System.out.println("1.Create an Account.");
			System.out.println("2.Login with Account.");
			System.out.println("3.Exit");
			System.out.println("Choose an Option:");
			option = a.scan.nextLine();
			switch (option) {
			case "1":
				a.create();				
				break;
			case "2":
				System.out.println("Enter Account Number:");
				int accno = Integer.parseInt(a.scan.nextLine());
				menu=a.log(accno);
				while(menu)
				{
					System.out.println();
					System.out.println("===============XYZ Banking Services=============");
					System.out.println("1.Display Balance.");
					System.out.println("2.Deposit into account.");
					System.out.println("3.Withdraw from account.");
					System.out.println("4.Fund Transfer.");
					System.out.println("5.Print Transactions.");
					System.out.println("6.Back.");
					System.out.println("Choose an Option:");
					option1 = a.scan.nextLine();
					switch (option1) {
					case "1":
						a.displayBal(accno);
						break;
					case "2":
						a.deposit(accno);
						break;
					case "3":
						a.withdraw(accno);
						break;
					case "4":
						a.transfer(accno);
						break;
					case "5":
						a.printTransaction(accno);
						break;
					case "6":
						menu=false;
						System.out.println();
						break;
					default:
						System.err.println("Invalid Option!");
						System.out.println();
						break;
					}					
				}
				break;
			case "3":
				System.exit(0);
				break;
			default:
				System.err.println("Invalid option choose either 1 or 2!");
				System.out.println();
				break;
			}
		}		
	}	
	
	public void create() {
		Customer cust = new Customer();
		System.out.println("Enter username:");
		try {
			cust.setUserName(scan.nextLine());
			System.out.println("Enter Initial Balance:");
			cust.setBalance(Float.parseFloat(scan.nextLine()));
			System.out.println("Enter Mobile no:");
			cust.setMobile(scan.nextLine());
			System.out.println("Enter Email id:");
			cust.setEmail(scan.nextLine());
			System.out.println("Enter Address:");
			cust.setAddress(scan.nextLine());
			System.out.println("Set password:");
			cust.setPin(Integer.parseInt(scan.nextLine()));		
			int id=bs.createAccount(cust);
			System.out.println("Dear "+cust.getUserName()+" account created successfully with AccNo: "+id);
		} catch (WalletException e) {
			System.err.println(e.getMessage());
			System.out.println();
		} catch (Exception e) {
			System.err.println(e.getMessage());
			System.out.println();
		}
	}
	
	public boolean log(int accno) {
		boolean flag = false;
		try {
			System.out.println("Enter password:");
			int upass=Integer.parseInt(scan.nextLine());		
			flag=bs.login(accno,upass);
			return flag;
		} catch (WalletException e) {
			System.err.println(e.getMessage());
			System.out.println();
		} catch (Exception e) {
			System.err.println(e.getMessage());
			System.out.println();
		}
		return flag;
	}
	
	
	public void displayBal(int accno) {
		float bal;
		try {	
			bal=bs.showBalance(accno);
			System.out.println();
			System.out.println("Account Number: "+accno);
			System.out.println("Balance: "+bal);
			System.out.println();
		} catch (WalletException e) {
			System.err.println(e.getMessage());
			System.out.println();
		} catch (Exception e) {
			System.err.println(e.getMessage());
			System.out.println();
		}
	}

	
	public void deposit(int accno) {
		try {	
			System.out.println("Enter how much you want to deposit: ");
			float input = Float.parseFloat(scan.nextLine());
			boolean bal=bs.deposit(accno,input);
			if(bal) {
				System.out.println("Account Credited with amount: "+input);
			}
			else {
				System.out.println("Transaction unsuccessful!");
			}
			System.out.println();
		} catch (WalletException e) {
			System.err.println(e.getMessage());
			System.out.println();
		} catch (Exception e) {
			System.err.println(e.getMessage());
			System.out.println();
		}
	}
	
	public void withdraw(int accno) {
		try {	
			System.out.println("Enter how much you want to withdraw: ");
			float input = Float.parseFloat(scan.nextLine());
			boolean bal=bs.withdraw(accno,input);
			if(bal) {
				System.out.println("Account Debited with amount: "+input);
			}
			else {
				System.out.println("Transaction unsuccessful!");
			}
			System.out.println();
			System.out.println();
		} catch (WalletException e) {
			System.err.println(e.getMessage());
			System.out.println();
		} catch (Exception e) {
			System.err.println(e.getMessage());
			System.out.println();
		}
	}

	public void transfer(int accno) {
		try {
			System.out.println("Enter the Account number to which you want to transfer: ");
			int accno2 = Integer.parseInt(scan.nextLine());
			System.out.println("Enter how much you want to transfer: ");
			float input = Float.parseFloat(scan.nextLine());
			boolean flag=bs.fundTransfer(accno, accno2, input);
			if(flag) {
				System.out.println("Transaction Complete!");
			}
		} catch (WalletException e) {
			System.err.println(e.getMessage());
			System.out.println();
		} catch (Exception e) {
			System.err.println(e.getMessage());
			System.out.println();
		}
	}
	
	public void printTransaction(int accno) {
	/*	try {
			String Transaction = bs.printTransaction(accno);
			System.out.println();
			System.out.println("All Transactions:");
			System.out.println(Transaction);
		} catch (WalletException e) {
			System.err.println(e.getMessage());
			System.out.println();
		} catch (Exception e) {
			System.err.println(e.getMessage());
			System.out.println();
		}*/
	try {
		boolean t=bs.printtransaction(accno);
	} catch (WalletException e) {
		System.err.println(e.getMessage());
		System.out.println();
	} catch (Exception e) {
		System.err.println(e.getMessage());
		System.out.println();
	}
	}
}