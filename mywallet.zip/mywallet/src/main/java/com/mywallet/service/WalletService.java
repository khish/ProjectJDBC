package com.mywallet.service;

import com.mywallet.bean.Customer;
import com.mywallet.dao.IWalletDao;
import com.mywallet.dao.WalletDao;
import com.mywallet.exception.WalletException;

public class WalletService implements IWalletService {

	IWalletDao wd = new WalletDao();
	
	
	public boolean validateName(String name) throws WalletException {
		try {
			if((name==null)||(name.equals(null))) {
				throw new WalletException("Name cannot be empty");	
			}
			else
			{
				if(!name.matches("[A-Z][a-z]{2,}")) {
					throw new WalletException("Name should start with capital letters and should contain minimum 3 characters!");
				}
				return true;
			}			
		} catch (WalletException e) {
			throw new WalletException(e.getMessage());
		}
	}
	
	@Override
	public int createAccount(Customer cust) throws WalletException {
		try {
			if(validateName(cust.getUserName()))
			{
				return wd.createAccount(cust);
			}
			else {
				return 0;
			}
		} catch (WalletException e) {
			throw new WalletException(e.getMessage());
		}
	}

	@Override
	public float showBalance(int accNumber) throws WalletException {
		// TODO Auto-generated method stub
		return wd.showBalance(accNumber);
	}

	@Override
	public boolean deposit(int num, float amount) throws WalletException {
		// TODO Auto-generated method stub
		return wd.deposit(num, amount);
	}

	@Override
	public boolean withdraw(int num, float amount) throws WalletException {
		// TODO Auto-generated method stub
		return wd.withdraw(num, amount);
	}

	@Override
	public boolean fundTransfer(int num, int num1, float amount) throws WalletException {
		// TODO Auto-generated method stub
		return wd.fundTransfer(num, num1, amount);
	}


	@Override
	public boolean login(int acc, int pass) throws WalletException {
		// TODO Auto-generated method stub
		return wd.login(acc, pass);
	}

	@Override
	public boolean printtransaction(int accountno) throws WalletException {
		// TODO Auto-generated method stub
		return wd.printtransaction(accountno);
	}

}
