package com.mywallet.dao;

public interface QueryMapper {
	
	public static final String INSERT_CUSTOMER="INSERT INTO CUSTOMER VALUES(CUSTOMER_SEQUENCE.NEXTVAL,?,?,?,?,?,?)";
	public static final String INSERT_TRANSACTION="INSERT INTO TRANSACTION VALUES(transaction_sequence.NEXTVAL,?,?,?)";
	public static final String UPDATE_CUSTOMER_DEPOSIT="UPDATE customer SET balance = balance + ? WHERE accnumber = ?";
	public static final String UPDATE_CUSTOMER_WITHDRAW="UPDATE customer SET balance = balance - ? WHERE accnumber = ?";
	public static final String VIEW_BALANCE_CUSTOMER="SELECT balance FROM customer WHERE accnumber = ?";
	public static final String PRINT_TRANSACTION="SELECT trid,accnumber,amount,trtype FROM transaction WHERE accnumber = ?";
	public static final String GET_PIN_CUSTOMER="SELECT pin FROM customer WHERE accnumber = ?";
	public static final String ACCOUNTNO_SEQUENCE="SELECT CUSTOMER_SEQUENCE.CURRVAL FROM DUAL";
    public static final String transfer_query1="insert into transfer values(transid_sequence.NEXTVAL,?,?,?,?)";
    public static final String date_query="select sysdate from dual";
    public static final String transfer_query_sequence="select transid_sequence.CURRVAL from dual";
    public static final String transfer_query2="select * from transfer where accountno=?";

}

/******************TABLESCRIPT*******************
create table customer(accnumber number(10),
name varchar2(30),
mobile varchar2(10),
email varchar2(30),
address varchar2(40),
balance number,
pin number);

CREATE SEQUENCE CUSTOMER_SEQUENCE START WITH 1 Increment by 1;
************************************************/