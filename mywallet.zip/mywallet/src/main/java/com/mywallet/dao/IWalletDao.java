package com.mywallet.dao;

import com.mywallet.bean.Customer;
import com.mywallet.exception.WalletException;

public interface IWalletDao {

	int createAccount(Customer cust) throws WalletException;
	boolean login(int acc,int pass) throws WalletException;
	float showBalance(int accNumber) throws WalletException;
	boolean deposit(int num,float amount) throws WalletException;
	boolean withdraw(int num,float amount) throws WalletException;
	boolean fundTransfer(int num,int num1,float amount) throws WalletException;
	boolean printtransaction(int accountno) throws WalletException;
	
}
