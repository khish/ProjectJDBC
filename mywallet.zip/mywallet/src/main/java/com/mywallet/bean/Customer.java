package com.mywallet.bean;

public class Customer {

	private int AccNo;
	private String UserName;
	private String mobile;
	private String email;
	private String address;
	private int pin;
	private Float Balance;
	
	public Customer() {
		AccNo = 0;
		UserName = null;
		mobile=null;
		email=null;
		address=null;
		pin = 0;
		Balance = 0.0f;
	}
	
	public Customer(int accNo, String userName, String mobile, String email, String address, int pin,
			Float balance) {
		super();
		AccNo = accNo;
		UserName = userName;
		this.mobile = mobile;
		this.email = email;
		this.address = address;
		this.pin = pin;
		Balance = balance;
	}

	public int getAccNo() {
		return AccNo;
	}


	public void setAccNo(int accNo) {
		AccNo = accNo;
	}


	public String getUserName() {
		return UserName;
	}


	public void setUserName(String userName) {
		UserName = userName;
	}

	public Float getBalance() {
		return Balance;
	}


	public void setBalance(Float balance) {
		Balance = balance;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public int getPin() {
		return pin;
	}

	public void setPin(int pin) {
		this.pin = pin;
	}

	
	/*@Override
	public String toString() {
		return "Bank [AccNo=" + AccNo + ", UserName=" + UserName + ", Pin=" + pin + ", Balance=" + Balance
				+ "]";
	}*/
	
}
