package org.cap.dao;

import java.util.List;

import org.cap.model.Student;
import org.springframework.stereotype.Repository;


public interface IStudentDao {

	public List<Student> getStudents();
	public Student findStudent(Integer studentId);
	public void update(Student student);
	
}
