package org.cap.service;

import java.util.List;

import org.cap.model.Account;
import org.cap.model.Transaction;

public interface IAccountService {
	public void createAccount(Account account);
	public List<Account> getAllAccounts(int customerId);
	public List<Account> getAccounts(int customerId);
	public List<Account> getAccountWithBalance(int custId);		
	public int getCustId(int accountId);
	public Account findAccount(int accId);
	public void fundTransfer(Transaction transaction);
}
