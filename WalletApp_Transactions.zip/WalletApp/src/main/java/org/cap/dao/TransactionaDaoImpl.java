package org.cap.dao;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.cap.model.Transaction;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository("transactionDao")
@Transactional
public class TransactionaDaoImpl implements ITransactionDao{

	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public void createTransaction(Transaction transaction) {
		
		/*Query query= entityManager.createQuery("select max(transactionId) from Transaction");
		List<Integer> max= query.getResultList();
		transaction.setTransactionId(max.get(0)+1)*/
		
		entityManager.persist(transaction);
	}
	
	@Override
	public List<Transaction> getTransactions(Integer custId) {
		// TODO Auto-generated method stub
		
		Query query= entityManager.createQuery("from Transaction transaction where transaction.customer.customerId=:cust");
		query.setParameter("cust", custId);
			List<Transaction> transaction= query.getResultList();
		for (Transaction trans : transaction) {
			System.out.println(trans);
		}
		
		return transaction;
	}

	@Override
	public List<Transaction> getDatedTransactions(Integer customerId, Date d1, Date d2) {
	
		Calendar cal = Calendar.getInstance();
		cal.setTime(d2);
		cal.add(Calendar.DATE, 1);
		Date d3= cal.getTime(); 
		 
		Query query= entityManager.createQuery("from Transaction tx where tx.customer.customerId=? and transactionDate between ? and ?");
		query.setParameter(0, customerId);
		query.setParameter(1,d1);
		query.setParameter(2,d3);
		
		List<Transaction> transactions= query.getResultList();
		for (Transaction transaction : transactions) {
			System.out.println(transaction);
		}
		return transactions;
	}
	
	@Override
	public List<Transaction> getDatedTransactions(Integer customerId, Date d1) {
	
		Query query= entityManager.createQuery("from Transaction tx where tx.customer.customerId=? and transactionDate like ?");
		query.setParameter(0, customerId);
		query.setParameter(1,d1);
		
		List<Transaction> transactions= query.getResultList();
		for (Transaction transaction : transactions) {
			System.out.println(transaction);
		}
		return transactions;
	}

	
}
