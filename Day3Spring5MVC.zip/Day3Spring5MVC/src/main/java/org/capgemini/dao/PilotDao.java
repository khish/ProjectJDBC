package org.capgemini.dao;

import org.capgemini.model.Pilot;

public interface PilotDao {

	public void save(Pilot pilot);
	
}
