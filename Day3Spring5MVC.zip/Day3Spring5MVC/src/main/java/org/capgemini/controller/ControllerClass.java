package org.capgemini.controller;

import javax.validation.Valid;

import org.capgemini.model.Pilot;
import org.capgemini.service.PilotService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class ControllerClass {

	@Autowired
	private PilotService pilotService;
	
	@RequestMapping("/Click")
	public ModelAndView doClick() {
		return new ModelAndView("Page2","content","Welcome to Spring 5!");
	}
	
	@RequestMapping("/validateLogin")
	public String validlogin(ModelMap map,
			@RequestParam("username")String username,
			@RequestParam("password")String password) {
		
		if((username.equals("khish"))&&(password.equals("khish123"))) {
			map.put("pilot", new Pilot());
			return "pilotForm";
		}
		return "redirect:/";
		
	}
	
	@PostMapping("/savePilot")
	public String showPilotDetails(
			@Valid @ModelAttribute("pilot") Pilot pilot,BindingResult result) {{
			if(result.hasErrors()) {
				return "pilotForm";
			}
			else {
				pilotService.save(pilot);
				System.out.println(pilot);
			return "showPilot";
			}
		}
	}
	
}
