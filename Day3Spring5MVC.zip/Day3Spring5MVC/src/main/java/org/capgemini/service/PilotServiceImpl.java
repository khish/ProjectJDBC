package org.capgemini.service;

import org.capgemini.dao.PilotDao;
import org.capgemini.model.Pilot;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("pilotService")
public class PilotServiceImpl implements PilotService {

	@Autowired
	private PilotDao pilotDao;
	
	@Override
	public void save(Pilot pilot) {
		//Your Business Logic goes here
		pilotDao.save(pilot);
	}

}
