package org.capgemini.service;

import org.capgemini.model.Pilot;

public interface PilotService {

	public void save(Pilot pilot);
	
}
