package org.cap;

public class PrototypeBean {

	private static int count=0;
	public PrototypeBean()
    {
           System.out.println("Prototype Bean Instantiated !!");
           count++;
           System.out.println("Value of count:"+count);
    }
	public PrototypeBean getPrototypeBean() {
		return this;
	}
}